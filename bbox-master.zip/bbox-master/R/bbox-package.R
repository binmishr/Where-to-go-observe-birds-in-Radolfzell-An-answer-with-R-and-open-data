#' bbox bounding boxes
#'
#' @docType package
#' @name bbox-package
#' @aliases bbox
NULL
