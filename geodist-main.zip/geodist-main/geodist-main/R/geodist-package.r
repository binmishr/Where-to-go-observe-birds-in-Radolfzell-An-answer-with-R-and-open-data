#' geodist.
#'
#' @name geodist
#' @docType package
#' @importFrom stats runif optim
#' @useDynLib geodist, .registration = TRUE
NULL
