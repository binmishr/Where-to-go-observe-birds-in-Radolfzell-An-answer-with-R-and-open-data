library(testthat)
library(geodist)

test_check("geodist")
