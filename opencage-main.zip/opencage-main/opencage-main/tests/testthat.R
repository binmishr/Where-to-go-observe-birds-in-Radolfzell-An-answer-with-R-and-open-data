library(testthat)

test_check("opencage")
