/***************************************************************************
 *  Project:    osmdata
 *  File:       get-bbox.h
 *  Language:   C++
 *
 *
 *  Description:    Header for rcpp_get_bbox
 *
 *  Limitations:
 *
 *  Dependencies:       none (rapidXML header included in osmdata)
 *
 *  Compiler Options:   -std=c++11 
 ***************************************************************************/

#pragma once

#include <Rcpp.h>

Rcpp::NumericMatrix rcpp_get_bbox (double xmin, double xmax, double ymin, double ymax);
Rcpp::NumericVector rcpp_get_bbox_sf (double xmin, double xmax, double ymin, double ymax);
