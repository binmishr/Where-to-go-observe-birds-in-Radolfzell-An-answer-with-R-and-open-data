library(testthat)
library(osmdata)

test_check("osmdata")
