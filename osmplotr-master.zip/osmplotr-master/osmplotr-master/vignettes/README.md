Compiled vignettes from the cran version of 'osmplotr' are here:

* [making maps](https://cran.r-project.org/web/packages/osmplotr/vignettes/making-maps.html)

* [making maps with data](https://cran.r-project.org/web/packages/osmplotr/vignettes/making-maps-with-data.html)

